//
//  ViewController.swift
//  MobvenBugKitTestSwiftApplication
//
//  Created by Baran Kaan Sert on 11.03.2016.
//  Copyright © 2016 Baran Kaan Sert. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        
        self.view.backgroundColor = UIColor.yellowColor()
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}

