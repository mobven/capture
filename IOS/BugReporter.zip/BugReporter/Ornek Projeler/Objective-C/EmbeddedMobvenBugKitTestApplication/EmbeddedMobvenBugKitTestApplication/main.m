//
//  main.m
//  EmbeddedMobvenBugKitTestApplication
//
//  Created by Baran Kaan Sert on 11.03.2016.
//  Copyright © 2016 Baran Kaan Sert. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "AppDelegate.h"

int main(int argc, char * argv[]) {
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([AppDelegate class]));
    }
}
