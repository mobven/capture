//
//  ViewController.m
//  EmbeddedMobvenBugKitTestApplication
//
//  Created by Baran Kaan Sert on 11.03.2016.
//  Copyright © 2016 Baran Kaan Sert. All rights reserved.
//

#import "ViewController.h"

@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    [self.view setBackgroundColor:[UIColor orangeColor]];
    
}



@end
