//
//  ViewController.m
//  MobvenBugKitTestApplication
//
//  Created by Baran Kaan Sert on 11.03.2016.
//  Copyright © 2016 Baran Kaan Sert. All rights reserved.
//

#import "ViewController.h"

@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
    [self.view setBackgroundColor:[UIColor yellowColor]];
}



@end
