//
//  MobvenBugKit.h
//  MobvenBugKit
//
//  Created by Ahmet Kazım Günay on 19/10/15.
//  Copyright © 2015 Ahmet Kazım Günay. All rights reserved.
//

#import <UIKit/UIKit.h>

//! Project version number for MobvenBugKit.
FOUNDATION_EXPORT double MobvenBugKitVersionNumber;

//! Project version string for MobvenBugKit.
FOUNDATION_EXPORT const unsigned char MobvenBugKitVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <MobvenBugKit/PublicHeader.h>
#import "MobvenBugReporter.h"

